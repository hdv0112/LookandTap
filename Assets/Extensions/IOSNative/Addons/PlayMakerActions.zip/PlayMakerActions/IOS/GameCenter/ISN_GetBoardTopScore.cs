﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Game Cneter")]
	public class ISN_GetBoardTopScore : FsmStateAction {
		
		public FsmString leaderboardId;
		public GCBoardTimeSpan  timeSpan ;
		public GCCollectionType collection;

		public FsmInt score;
		
		
		public override void OnEnter() {
			
			GCLeaderBoard board = GameCenterManager.GetLeaderBoard(leaderboardId.Value);


			if(board != null) {
				GCScore s = board.GetScore(1, timeSpan, collection);
				if(s != null) {
					Debug.Log("ISN_GetBoardTopScore: Score was already loaded");
					score.Value = (int) s.GetLongScore();
					Finish();
					return;
				}
				
			} 
			
			SendScoreLoadRequest();
			
			
			
		}
		
		private void SendScoreLoadRequest() {
			Debug.Log("ISN_GetBoardTopScore: Sending score Request");





			GameCenterManager.OnScoresListLoaded -= OnScoresListLoaded;
			GameCenterManager.OnScoresListLoaded += OnScoresListLoaded;
			GameCenterManager.loadScore(leaderboardId.Value, 1, 5,timeSpan, collection);

		}


		private void OnScoresListLoaded (ISN_Result res) {
			Debug.Log("ISN_GetBoardTopScore: OnScoresListLoaded");
			score.Value = 0;

			if(res.IsSucceeded) {
				GCLeaderBoard board = GameCenterManager.GetLeaderBoard(leaderboardId.Value);
				if(board != null) {
					GCScore s = board.GetScore(1, timeSpan, collection);
					if(s != null) {
						Debug.Log("ISN_GetBoardTopScore: Score Retrived");
						score.Value = (int) s.GetLongScore();
					}
					
				} 
			}

			Finish();
		}

	}
}



