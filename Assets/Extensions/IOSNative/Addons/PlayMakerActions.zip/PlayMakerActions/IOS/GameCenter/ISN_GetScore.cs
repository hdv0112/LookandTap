﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Game Cneter")]
	public class ISN_GetScore : FsmStateAction {

		public FsmString leaderboardId;
		public FsmInt score;


		public override void OnEnter() {

			GCLeaderBoard board = GameCenterManager.GetLeaderBoard(leaderboardId.Value);
			if(board != null) {
				GCScore s =  board.GetCurrentPlayerScore(GCBoardTimeSpan.ALL_TIME, GCCollectionType.GLOBAL);
				if(s != null) {
					Debug.Log("ISN_GetScore: Score was already loaded");
					score.Value = (int) s.GetLongScore();
					Finish();
					return;
				}

			}

			SendScoreLoadRequest();


			
		}

		private void SendScoreLoadRequest() {
			Debug.Log("ISN_GetScore: Sending score Request");

			GameCenterManager.OnPlayerScoreLoaded -= OnPlayerScoreLoaded;
			GameCenterManager.OnPlayerScoreLoaded += OnPlayerScoreLoaded;
			GameCenterManager.loadCurrentPlayerScore(leaderboardId.Value);
		}

		private void OnPlayerScoreLoaded (ISN_PlayerScoreLoadedResult res) {
			if(res.IsSucceeded) {
				score.Value = (int) res.loadedScore.GetLongScore();
			} else {
				score.Value = 0;
			}
			Finish();

		}

	}
}

