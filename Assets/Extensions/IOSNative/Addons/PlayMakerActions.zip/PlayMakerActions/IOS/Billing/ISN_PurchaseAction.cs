﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("IOS Native - Billing")]
	[Tooltip("Aaction will start purchase flow on device. In Editor mode Success event will fired immediately")]
	public class ISN_PurchaseAction : FsmStateAction {


		[Tooltip("Event fired when Store Kit purchase is deferred")]
		public FsmEvent deferredEvent;

		[Tooltip("Event fired when Store Kit purchase is complete")]
		public FsmEvent purchasedEvent;

		[Tooltip("Event fired when Store Kit purchase is failed")]
		public FsmEvent failEvent;


		[Tooltip("Purhase product Id")]
		public string ProductID  = "";


		[UIHint(UIHint.Variable)]
		public FsmString receipt;

		

		public override void OnEnter() {

			new IOSBillingInitChecker(OnBillingInit);

		}

		private void OnBillingInit() {
			IOSInAppPurchaseManager.instance.OnTransactionComplete += OnTransactionComplete;
			IOSInAppPurchaseManager.instance.buyProduct(ProductID);
		}

		void OnTransactionComplete (IOSStoreKitResponse resp) {
			if(!resp.productIdentifier.Equals(ProductID)) {
				return;
			}

			IOSInAppPurchaseManager.instance.OnTransactionComplete -= OnTransactionComplete;

			switch(resp.state) {
			case InAppPurchaseState.Purchased:
			case InAppPurchaseState.Restored:
				receipt.Value = resp.receipt;
				Fsm.Event(purchasedEvent);
				break;
			case InAppPurchaseState.Deferred:
				Fsm.Event(deferredEvent);
				break;
			case InAppPurchaseState.Failed:
				Fsm.Event(failEvent);
				break;
			}

			Finish();
		}

		
	}
}
