using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Billing")]
	[Tooltip("Restore purchases, resotred event will be fired for ectach restored purchase")]
	public class ISN_RestorePurchases : FsmStateAction {
		
				


		public FsmString[] restoredProducts;
		public FsmString   currentRestoredItem;

		[Tooltip("Event fired when Store Kit product restored")]
		public FsmEvent successEvent;
		
		[Tooltip("Event fired when Store Kit purchase is failed")]
		public FsmEvent failEvent;

		[Tooltip("Event fired when Store Kit purchase is failed")]
		public FsmEvent ItemRestoredEvent;


		private List<FsmString> restoredProductsCash =  new List<FsmString>();


		public override void Reset() {
			restoredProductsCash = new List<FsmString>();
		}


		public override void OnEnter() {

			new IOSBillingInitChecker(OnBillingInit);

			#if UNITY_EDITOR
			Fsm.Event(successEvent);
			Finish();
			return;
			#endif
			
		}

		private void OnBillingInit() {

			IOSInAppPurchaseManager.instance.OnTransactionComplete += OnTransactionComplete;
			IOSInAppPurchaseManager.instance.addEventListener(IOSInAppPurchaseManager.RESTORE_TRANSACTION_COMPLETE, OnComplete);
			IOSInAppPurchaseManager.instance.restorePurchases();
		}



		void OnTransactionComplete (IOSStoreKitResponse resp) {


			switch(resp.state) {
			case InAppPurchaseState.Purchased:
			case InAppPurchaseState.Restored:
				restoredProductsCash.Add(resp.productIdentifier);
				currentRestoredItem.Value = resp.productIdentifier;
				Fsm.Event(ItemRestoredEvent);
				break;
			case InAppPurchaseState.Deferred:
			case InAppPurchaseState.Failed:
				Fsm.Event(failEvent);
				break;
			}


		}

	

		private void OnComplete() {
			IOSInAppPurchaseManager.instance.OnTransactionComplete -= OnTransactionComplete;
			IOSInAppPurchaseManager.instance.removeEventListener(IOSInAppPurchaseManager.RESTORE_TRANSACTION_COMPLETE, OnComplete);


			restoredProducts = restoredProductsCash.ToArray ();
			Fsm.Event(successEvent);
			Finish();
			
		}
		
	
		
	}
}




