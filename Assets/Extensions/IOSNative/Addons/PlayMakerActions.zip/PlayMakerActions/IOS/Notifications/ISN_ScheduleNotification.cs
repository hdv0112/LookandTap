﻿using UnityEngine;
using System.Collections;
using HutongGames.PlayMaker;
	
namespace HutongGames.PlayMaker.Actions {
		
	[ActionCategory("IOS Native - Notifications")]
	public class ISN_ScheduleNotification : FsmStateAction {

		public FsmInt time;
		public FsmString message;
		public FsmBool sound;
		public FsmInt badges;
		
		public override void OnEnter() {
			IOSNotificationController.instance.ScheduleNotification (time.Value, message.Value, sound.Value, badges.Value);
			Finish();
		}
	}
}
