﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Notifications")]
	public class ISN_RequestNotificationsPermitions : FsmStateAction {

		public override void OnEnter() {
			IOSNotificationController.instance.RequestNotificationPermitions();
			Finish();
		}
	}
}