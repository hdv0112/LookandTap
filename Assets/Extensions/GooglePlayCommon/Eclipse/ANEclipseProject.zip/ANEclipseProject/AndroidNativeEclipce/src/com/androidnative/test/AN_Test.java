package com.androidnative.test;

import android.util.Log;

public class AN_Test {

	
	public static void StaticFunc() {
		Log.d("AndroidNative", "StaticFunc got called");
	}
}
