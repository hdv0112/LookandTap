package com.androidnative.features.notifications;

import java.util.Calendar;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.util.Log;

import com.androidnative.AndroidNativeBridge;
import com.unity3d.player.UnityPlayer;



public class LocalNotificationsController {
	
	public static String TITILE_KEY  = "TITILE_KEY";
	public static String MESSAGE_KEY = "MESSAGE_KEY";
	public static String ID_KEY 	 = "ID_KEY";

	
	private static LocalNotificationsController _inctance = null;
	
	public static LocalNotificationsController GetInstance() {
		if (_inctance == null) {
			_inctance = new LocalNotificationsController();
		}

		return _inctance;
	}
	
	@SuppressLint("NewApi") 
	public void requestCurrentAppLaunchNotificationId() {
		int id = -1;
		if(AndroidNativeBridge.GetInstance().getIntent().getExtras() != null) {
			if(AndroidNativeBridge.GetInstance().getIntent().hasExtra(LocalNotificationsController.ID_KEY)) {
				id = AndroidNativeBridge.GetInstance().getIntent().getExtras().getInt(LocalNotificationsController.ID_KEY);
			}
		}
		
		UnityPlayer.UnitySendMessage("AndroidNotificationManager", "OnNotificationIdLoadedEvent",  Integer.toString(id));
	}
	
	@SuppressLint("NewApi")
	public void scheduleNotification(String title, String message, int seconds, int id) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.SECOND, seconds);

		Intent resultIntent = new Intent(AndroidNativeBridge.GetInstance(), LocalNotificationReceiver.class);
		resultIntent.putExtra(TITILE_KEY, title);
		resultIntent.putExtra(MESSAGE_KEY, message);
		resultIntent.putExtra(ID_KEY, id);
		
		AlarmManager am = (AlarmManager) AndroidNativeBridge.GetInstance().getSystemService(Activity.ALARM_SERVICE);
		// In reality, you would want to have a static variable for the request code instead of 192837
		PendingIntent sender = PendingIntent.getBroadcast(AndroidNativeBridge.GetInstance(), id, resultIntent, PendingIntent.FLAG_UPDATE_CURRENT);
		// start the activity when the user clicks the notification text
		am.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), sender);
		
		Log.d(AndroidNativeBridge.TAG, "LocalNotificationsController scheduleNotification with id: " + id);
	}
	
	
	@SuppressLint("NewApi")
	public void canselNotification(int id) {
	
		Intent resultIntent = new Intent(AndroidNativeBridge.GetInstance(), LocalNotificationReceiver.class);
		//resultIntent.putExtra("title", title);
		//resultIntent.putExtra("message", message);
		
		AlarmManager am = (AlarmManager) AndroidNativeBridge.GetInstance().getSystemService(Activity.ALARM_SERVICE);
		// In reality, you would want to have a static variable for the request code instead of 192837
		PendingIntent sender = PendingIntent.getBroadcast(AndroidNativeBridge.GetInstance(), id, resultIntent, PendingIntent.FLAG_UPDATE_CURRENT);
		// start the activity when the user clicks the notification text
		am.cancel(sender);
		
		Log.d(AndroidNativeBridge.TAG, "LocalNotificationsController canselNotification with id:" + id);
	}
	
}
