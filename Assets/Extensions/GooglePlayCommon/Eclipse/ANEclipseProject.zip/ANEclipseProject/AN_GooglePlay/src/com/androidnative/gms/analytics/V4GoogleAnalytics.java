package com.androidnative.gms.analytics;



import com.androidnative.gms.utils.AnUtility;
import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Logger.LogLevel;
import com.google.android.gms.analytics.Tracker;
import com.google.android.gms.analytics.ecommerce.Product;
import com.google.android.gms.analytics.ecommerce.ProductAction;

import android.app.Activity;
import android.util.Log;



public class V4GoogleAnalytics {
	
	private static V4GoogleAnalytics _instance = null;
	
	private  Activity mainActivity = null;
	private  boolean isTrackingStarted = false;
	private Tracker AppTracker = null;
	
	
	
	public static V4GoogleAnalytics GetInstance() {
		if(_instance == null) {
			_instance =  new V4GoogleAnalytics();
		}
		
		return _instance;
	}
	
	public void startAnalyticsTracking(Activity activity) {
		
		if(isTrackingStarted) {
			return;
		}
		
		mainActivity = activity;
		isTrackingStarted = true;
	
		Log.d("AndroidNative", "Analytics Tracking Sarted");
		getTracker();
	}
	
	public Tracker getTracker() {
			if(AppTracker == null) {
				String ga_trackingId = getStringResourceByName("ga_trackingId");
				Log.d("AndroidNative", "ga_trackingId: " + ga_trackingId);
				GoogleAnalytics analytics = GoogleAnalytics.getInstance(mainActivity);
				AppTracker =  analytics.newTracker(ga_trackingId);
			}
			return AppTracker;
	  }
    
	
	private String getStringResourceByName(String aString) {
		String packageName = AnUtility.GetLauncherActivity().getPackageName();
		int resId = AnUtility.GetLauncherActivity().getResources().getIdentifier(aString, "string", packageName);
		return AnUtility.GetLauncherActivity().getString(resId);
	}
    
    public void SetTracker(String trackingID) {

    	 GoogleAnalytics analytics = GoogleAnalytics.getInstance(mainActivity);
    	 AppTracker =  analytics.newTracker(trackingID);
    }
    
    
    public void enableAdvertisingIdCollection(boolean mode) {
    	getTracker().enableAdvertisingIdCollection(mode);
    }
  
 

	public void SendView(String appScreen) {
    	
    	Tracker t = getTracker();

        // Set screen name.
        t.setScreenName(appScreen);

         // Send a screen view.
        t.send(new HitBuilders.AppViewBuilder().build());
        
        Log.d("AndroidNative", "GA: SendView " + appScreen);
    }
    
    public void SendView() {
    	Tracker t = getTracker();
    	t.send(new HitBuilders.AppViewBuilder().build());
    }
    
    
    public void sendEvent(String category, String action, String label, String value) {
  
	
    	Tracker t = getTracker();
    	HitBuilders.EventBuilder builder = new HitBuilders.EventBuilder();
    	builder.setCategory(category).setAction(action).setLabel(label);
    	if(!value.equals("null")) {
    		builder.setValue(Long.parseLong(value));
    	}
    		
    	
    	Log.d("AndroidNative", "GA: sendEvent");

    	t.send(builder.build());
    }
    
    public void sendEvent(String category, String action, String label, String value, String key, String v) {
    	
    	
    	Tracker t = getTracker();
    	HitBuilders.EventBuilder builder = new HitBuilders.EventBuilder();
    	builder.setCategory(category).setAction(action).setLabel(label);
    	if(!value.equals("null")) {
    		builder.setValue(Long.parseLong(value));
    	}
    	builder.set(key, v);
    	t.send(builder.build());
 
        
    }
    
    
    
    public void setKey(String key, String value) {
    	Tracker t = getTracker();
    	t.set(key, value);

    }
    
    public void clearKey(String key) {
    	Tracker t = getTracker();
    	t.set(key, null);
    	
    }
    
    public void sendTiming(String category, String intervalInMilliseconds, String name, String label) {
    	Long l = Long.parseLong(intervalInMilliseconds);
    	
    	
    	Tracker t = getTracker();
    	HitBuilders.TimingBuilder builder = new HitBuilders.TimingBuilder();
    	builder.setCategory(category).setValue(l);
    	
    	if(!name.equals("null")) {
    		builder.setVariable(name);
    	}
    	if(!label.equals("null")) {
    		builder.setLabel(label);
    	}
   
    	
    	t.send(builder.build());
    	
    	
    	
    }
    
    public void CreateTransaction(String transactionId, String affiliation, String revenue, String tax, String shipping, String currencyCode) {
    	
    	 ProductAction productAction = new ProductAction(ProductAction.ACTION_PURCHASE)
         .setTransactionId(transactionId)
         .setTransactionAffiliation(affiliation)
         .setTransactionRevenue( Double.parseDouble(revenue))
         .setTransactionTax(Double.parseDouble(tax))
         .setTransactionShipping(Double.parseDouble(shipping))
         .setTransactionCouponCode(currencyCode);
    	 
    	 HitBuilders.ScreenViewBuilder builder = new HitBuilders.ScreenViewBuilder().setProductAction(productAction);
    	 
    	 Tracker t = getTracker();
    		  
    	 t.send(builder.build());   	
    	 
    }
    
    public void CreateItem(String transactionId, String name, String sku, String category, String price, String quantity, String currencyCode) {
    	
    	 Product product =  new Product()
         .setId(sku)
         .setName(name)
         .setCategory(category);
    	 
    	 HitBuilders.ScreenViewBuilder builder = new HitBuilders.ScreenViewBuilder()
         .addProduct(product);

    	 Tracker t = getTracker();
    	 t.send(builder.build());   

    }
    
    
    public void SetLogLevel(int lvl) {
    	
    	switch(lvl) {
	    	case 0:
	    		
	    		GoogleAnalytics.getInstance(mainActivity).getLogger().setLogLevel(LogLevel.VERBOSE);
	    		break;
	    	case 1:
	    		GoogleAnalytics.getInstance(mainActivity).getLogger().setLogLevel(LogLevel.INFO);
	    		break;
	    	case 2:
	    		GoogleAnalytics.getInstance(mainActivity).getLogger().setLogLevel(LogLevel.WARNING);
	    		break;
	    	case 3:
	    		GoogleAnalytics.getInstance(mainActivity).getLogger().setLogLevel(LogLevel.ERROR);
	    		break;
    	}
    	
    	
    	
    }
    
    


    public void setDryRun(boolean mode) {
    	 GoogleAnalytics analytics = GoogleAnalytics.getInstance(mainActivity);
    	 analytics.setDryRun(mode);
    }
    


	
	
	
	
	
}

