package com.androidnative.gms.listeners.network;

import android.util.Log;


import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.games.multiplayer.realtime.RealTimeMessage;
import com.google.android.gms.games.multiplayer.realtime.RealTimeMessageReceivedListener;
import com.unity3d.player.UnityPlayer;

public class AN_RealTimeMessageReceivedListener implements RealTimeMessageReceivedListener {



	@Override
	public void onRealTimeMessageReceived(RealTimeMessage rtm) {
		Log.d(GameClientManager.TAG, "onRealTimeMessageReceived+");

		byte[] buf = rtm.getMessageData();
		String sender = rtm.getSenderParticipantId();

		String data = sender + GameClientManager.UNITY_SPLITTER;
		for(int i = 0; i < buf.length; i++) {
			if(i != 0) {
				data += ",";
			}
			data += String.valueOf(buf[i]);
		}
		
		Log.d("onRealTimeMessageReceived", data);
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnMatchDataRecieved", data);
		
	}

}
